/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'hemp-dark': '#1a3c1a',
        'hemp-green': '#2d5a2d',
        'hemp-light': '#4a7c4a',
        'hemp-gold': '#c9a227',
        'hemp-purple': '#6b2d5c',
        'hemp-red': '#8b1a1a',
      }
    },
  },
  plugins: [],
}
