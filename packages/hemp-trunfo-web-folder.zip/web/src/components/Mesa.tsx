import { usePartida } from '../hooks/usePartida'
import { useIA } from '../hooks/useIA'
import { CartaVisual } from './Carta'
import { motion, AnimatePresence } from 'framer-motion'

export function Mesa() {
  const { partida, iniciar, jogar, jogadorHumano, jogadorIA, ehMinhaVez, cartaHumano, cartaIA } = usePartida()
  useIA(1500)

  if (!partida) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-hemp-dark to-black">
        <div className="text-center">
          <motion.h1 className="text-5xl font-bold text-hemp-gold mb-4" initial={{opacity:0}} animate={{opacity:1}}>
            🌿 Hemp Trunfo
          </motion.h1>
          <p className="text-gray-400 mb-8">O jogo de cartas das genéticas</p>
          <button onClick={() => iniciar(['Você', 'Computador'])} className="px-8 py-4 bg-hemp-green hover:bg-hemp-light rounded-xl text-xl font-bold text-white transition-all hover:scale-105">
            ▶ Iniciar Partida
          </button>
        </div>
      </div>
    )
  }

  if (partida.finalizada) {
    const v = partida.jogadores.find(j => j.id === partida.vencedor)
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-hemp-dark to-black">
        <div className="text-center">
          <h1 className="text-6xl font-bold text-hemp-gold mb-4">🏆 Fim de Jogo!</h1>
          <p className="text-3xl mb-2">{v?.nome} venceu!</p>
          <p className="text-gray-400 mb-8">Rodadas: {partida.rodada - 1}</p>
          <button onClick={() => iniciar(['Você', 'Computador'])} className="px-8 py-4 bg-hemp-green hover:bg-hemp-light rounded-xl text-xl font-bold text-white">
            🔄 Jogar Novamente
          </button>
        </div>
      </div>
    )
  }

  const total = (jogadorHumano?.cartas.length ?? 0) + (jogadorIA?.cartas.length ?? 0) + partida.monteEmpate.length

  return (
    <div className="min-h-screen bg-gradient-to-b from-hemp-dark to-black p-4">
      {/* HEADER */}
      <div className="flex justify-between items-center mb-6 max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold text-hemp-gold">🌿 Hemp Trunfo</h1>
        <div className="flex gap-3">
          <span className="bg-hemp-dark border border-hemp-green/50 px-4 py-2 rounded-full text-sm">
            Rodada <strong className="text-hemp-gold">{partida.rodada}</strong>
          </span>
          <span className={`px-4 py-2 rounded-full text-sm font-semibold ${ehMinhaVez ? 'bg-hemp-green text-white' : 'bg-hemp-purple text-white'}`}>
            {ehMinhaVez ? '🔥 Sua vez' : `⏳ ${partida.jogadores[partida.turnoAtual].nome}`}
          </span>
        </div>
      </div>

      {/* ÁREA DE JOGO - LADO A LADO */}
      <div className="flex justify-center items-start gap-8 md:gap-16 mb-8">

        {/* JOGADOR */}
        <div className="flex flex-col items-center">
          <div className="mb-3 text-center">
            <p className="font-bold text-hemp-gold text-lg">{jogadorHumano?.nome}</p>
            <p className="text-sm text-gray-400">{jogadorHumano?.cartas.length} cartas</p>
          </div>
          <div className="relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-hemp-gold text-black text-xs font-bold px-3 py-1 rounded-full z-10">
              SUA CARTA
            </div>
            {cartaHumano && (
              <CartaVisual 
                carta={cartaHumano} 
                virada={true}
                onEscolher={jogar}
                podeEscolher={ehMinhaVez}
              />
            )}
          </div>
          {!ehMinhaVez && <p className="mt-3 text-sm text-gray-400 animate-pulse">⏳ Aguardando...</p>}
        </div>

        {/* VS */}
        <div className="flex flex-col items-center justify-center pt-24">
          <div className="text-4xl font-bold text-hemp-gold">VS</div>
        </div>

        {/* IA */}
        <div className="flex flex-col items-center">
          <div className="mb-3 text-center">
            <p className="font-bold text-gray-400 text-lg">{jogadorIA?.nome}</p>
            <p className="text-sm text-gray-500">{jogadorIA?.cartas.length} cartas</p>
          </div>
          <div className="relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gray-600 text-white text-xs font-bold px-3 py-1 rounded-full z-10">
              OPONENTE
            </div>
            {cartaIA && (
              <CartaVisual 
                carta={cartaIA} 
                virada={!ehMinhaVez}
              />
            )}
          </div>
        </div>
      </div>

      {/* INFO */}
      <div className="max-w-2xl mx-auto grid grid-cols-2 gap-4 mb-6">
        <div className="bg-hemp-dark/80 border border-hemp-green/30 rounded-xl p-4 text-center">
          <p className="text-xs text-gray-400 uppercase">Monte de Empate</p>
          <p className="text-3xl font-bold text-hemp-gold">{partida.monteEmpate.length}</p>
        </div>
        <div className="bg-hemp-dark/80 border border-hemp-green/30 rounded-xl p-4 text-center">
          <p className="text-xs text-gray-400 uppercase">Total no Jogo</p>
          <p className="text-3xl font-bold text-hemp-gold">{total}</p>
        </div>
      </div>

      {/* HISTÓRICO */}
      <div className="max-w-2xl mx-auto bg-hemp-dark/80 border border-hemp-gold/20 rounded-xl p-4">
        <h3 className="text-hemp-gold font-bold mb-3 text-sm uppercase">📜 Histórico</h3>
        <div className="space-y-2 text-sm max-h-40 overflow-y-auto">
          <AnimatePresence>
            {partida.historico.slice(-6).map((h, i) => (
              <motion.p key={i} className="text-gray-300 border-l-2 border-hemp-gold/30 pl-3"
                initial={{opacity:0, x:-20}} animate={{opacity:1, x:0}} transition={{delay:i*0.05}}>
                {h}
              </motion.p>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}
