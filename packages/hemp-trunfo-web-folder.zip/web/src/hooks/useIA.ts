import { useEffect, useCallback } from 'react'
import { useJogoStore } from '../store/jogoStore'
import { type Atributo } from '@hemp-trunfo/engine'

const ATRIBUTOS: Atributo[] = ['thc', 'relaxamento', 'foco', 'felicidade', 'fome', 'sono']

export function useIA(delayMs = 1500) {
  const { partida, jogarAtributo } = useJogoStore()

  const escolher = useCallback(() => ATRIBUTOS[Math.floor(Math.random() * ATRIBUTOS.length)], [])

  useEffect(() => {
    if (!partida || partida.finalizada || partida.turnoAtual !== 1) return
    const timer = setTimeout(() => jogarAtributo(escolher()), delayMs)
    return () => clearTimeout(timer)
  }, [partida, jogarAtributo, escolher, delayMs])
}
