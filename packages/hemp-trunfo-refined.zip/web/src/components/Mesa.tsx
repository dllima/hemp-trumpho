import { useState, useEffect } from 'react'
import { usePartida } from '../hooks/usePartida'
import { useIA } from '../hooks/useIA'
import { CartaVisual } from './Carta'
import { motion, AnimatePresence } from 'framer-motion'
import type { Atributo } from '@hemp-trunfo/engine'

export function Mesa() {
  const { partida, iniciar, jogar, jogadorHumano, jogadorIA, ehMinhaVez, cartaHumano, cartaIA } = usePartida()
  const [atributoSelecionado, setAtributoSelecionado] = useState<Atributo | null>(null)
  const [mostrarResultado, setMostrarResultado] = useState(false)
  const [cartasVoando, setCartasVoando] = useState(false)

  useIA(1500)

  const handleEscolher = (attr: Atributo) => {
    setAtributoSelecionado(attr)
    setMostrarResultado(true)
    setCartasVoando(true)
    jogar(attr)

    setTimeout(() => {
      setAtributoSelecionado(null)
      setMostrarResultado(false)
      setCartasVoando(false)
    }, 2000)
  }

  if (!partida) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-hemp-dark to-black">
        <div className="text-center px-4">
          <motion.h1 className="text-5xl md:text-6xl font-bold text-hemp-gold mb-4" initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}}>
            🌿 Hemp Trumpho
          </motion.h1>
          <p className="text-gray-400 mb-2 text-lg">O jogo de cartas das genéticas</p>
          <p className="text-gray-500 mb-8 text-sm">28 genéticas · 7 atributos · 1 vencedor</p>
          <motion.button 
            onClick={() => iniciar(['Você', 'Computador'])}
            className="px-8 py-4 bg-hemp-green hover:bg-hemp-light rounded-xl text-xl font-bold text-white transition-all hover:scale-105 shadow-lg"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            ▶ Iniciar Partida
          </motion.button>
          <div className="mt-12 flex justify-center gap-3 text-2xl">
            <span>🍃</span><span>🧘</span><span>👁️</span><span>😊</span><span>🍴</span><span>😴</span>
          </div>
        </div>
      </div>
    )
  }

  if (partida.finalizada) {
    const v = partida.jogadores.find((j: { id: string }) => j.id === partida.vencedor)
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-hemp-dark to-black relative overflow-hidden">
        <Confetti />
        <div className="text-center z-10 px-4">
          <motion.h1 className="text-6xl md:text-7xl font-bold text-hemp-gold mb-4" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring" }}>
            🏆 Fim de Jogo!
          </motion.h1>
          <p className="text-3xl md:text-4xl mb-2">{v?.nome} venceu!</p>
          <p className="text-gray-400 mb-8">Rodadas: {partida.rodada - 1}</p>
          <button onClick={() => iniciar(['Você', 'Computador'])} className="px-8 py-4 bg-hemp-green hover:bg-hemp-light rounded-xl text-xl font-bold text-white transition-all hover:scale-105">
            🔄 Jogar Novamente
          </button>
        </div>
      </div>
    )
  }

  const total = (jogadorHumano?.cartas.length ?? 0) + (jogadorIA?.cartas.length ?? 0) + partida.monteEmpate.length
  const iaJogou = !ehMinhaVez && mostrarResultado

  return (
    <div className="min-h-screen bg-gradient-to-b from-hemp-dark to-black p-4 md:p-8">
      {/* HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-6 max-w-4xl mx-auto gap-3">
        <h1 className="text-2xl font-bold text-hemp-gold">🌿 Hemp Trumpho</h1>
        <div className="flex gap-3">
          <span className="bg-hemp-dark border border-hemp-green/50 px-4 py-2 rounded-full text-sm">
            Rodada <strong className="text-hemp-gold">{partida.rodada}</strong>
          </span>
          <span className={`px-4 py-2 rounded-full text-sm font-semibold ${ehMinhaVez ? 'bg-hemp-green text-white' : 'bg-hemp-purple text-white'}`}>
            {ehMinhaVez ? '🔥 Sua vez' : `⏳ ${partida.jogadores[partida.turnoAtual].nome}`}
          </span>
        </div>
      </div>

      {/* ÁREA DE JOGO - RESPONSIVO */}
      <div className="flex flex-col md:flex-row justify-center items-center md:items-start gap-6 md:gap-12 mb-8">

        {/* JOGADOR */}
        <div className="flex flex-col items-center order-1">
          <div className="mb-3 text-center">
            <p className="font-bold text-hemp-gold text-lg">{jogadorHumano?.nome}</p>
            <p className="text-sm text-gray-400">{jogadorHumano?.cartas.length} cartas</p>
          </div>
          <div className="relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-hemp-gold text-black text-xs font-bold px-3 py-1 rounded-full z-10">
              SUA CARTA
            </div>
            {cartaHumano && (
              <CartaVisual 
                carta={cartaHumano} 
                virada={true}
                onEscolher={handleEscolher}
                podeEscolher={ehMinhaVez}
                ehMinhaVez={ehMinhaVez}
                atributoSelecionado={atributoSelecionado}
              />
            )}
          </div>
          {!ehMinhaVez && <p className="mt-3 text-sm text-gray-400 animate-pulse">⏳ Aguardando...</p>}
        </div>

        {/* VS */}
        <div className="flex flex-col items-center justify-center md:pt-24 order-2">
          <div className="text-4xl font-bold text-hemp-gold">VS</div>
          {mostrarResultado && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mt-2 text-sm text-hemp-gold font-bold text-center"
            >
              {partida.historico[partida.historico.length - 1]}
            </motion.div>
          )}
        </div>

        {/* IA */}
        <div className="flex flex-col items-center order-3">
          <div className="mb-3 text-center">
            <p className="font-bold text-gray-400 text-lg">{jogadorIA?.nome}</p>
            <p className="text-sm text-gray-500">{jogadorIA?.cartas.length} cartas</p>
          </div>
          <div className="relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gray-600 text-white text-xs font-bold px-3 py-1 rounded-full z-10">
              OPONENTE
            </div>
            {cartaIA && (
              <CartaVisual 
                carta={cartaIA} 
                virada={!ehMinhaVez || iaJogou}
                podeEscolher={false}
                atributoSelecionado={iaJogou ? atributoSelecionado : null}
              />
            )}
          </div>
        </div>
      </div>

      {/* INFO */}
      <div className="max-w-2xl mx-auto grid grid-cols-2 gap-4 mb-6">
        <div className="bg-hemp-dark/80 border border-hemp-green/30 rounded-xl p-4 text-center">
          <p className="text-xs text-gray-400 uppercase">Monte de Empate</p>
          <p className="text-3xl font-bold text-hemp-gold">{partida.monteEmpate.length}</p>
        </div>
        <div className="bg-hemp-dark/80 border border-hemp-green/30 rounded-xl p-4 text-center">
          <p className="text-xs text-gray-400 uppercase">Total no Jogo</p>
          <p className="text-3xl font-bold text-hemp-gold">{total}</p>
        </div>
      </div>

      {/* HISTÓRICO */}
      <div className="max-w-2xl mx-auto bg-hemp-dark/80 border border-hemp-gold/20 rounded-xl p-4">
        <h3 className="text-hemp-gold font-bold mb-3 text-sm uppercase">📜 Histórico</h3>
        <div className="space-y-2 text-sm max-h-40 overflow-y-auto">
          <AnimatePresence>
            {partida.historico.slice(-6).map((h: string, i: number) => (
              <motion.p key={`${h}-${i}`} className="text-gray-300 border-l-2 border-hemp-gold/30 pl-3"
                initial={{opacity:0, x:-20}} animate={{opacity:1, x:0}} transition={{delay:i*0.05}}>
                {h}
              </motion.p>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}

function Confetti() {
  const [pieces, setPieces] = useState<number[]>([])

  useEffect(() => {
    const p = Array.from({ length: 50 }, (_, i) => i)
    setPieces(p)
  }, [])

  const colors = ['#c9a227', '#22c55e', '#ef4444', '#3b82f6', '#f59e0b', '#8b5cf6']

  return (
    <div className="fixed inset-0 pointer-events-none z-0">
      {pieces.map((i) => (
        <div
          key={i}
          className="confetti"
          style={{
            left: `${Math.random() * 100}%`,
            backgroundColor: colors[i % colors.length],
            animationDelay: `${Math.random() * 2}s`,
            animationDuration: `${2 + Math.random() * 2}s`,
            width: `${5 + Math.random() * 10}px`,
            height: `${5 + Math.random() * 10}px`,
            borderRadius: Math.random() > 0.5 ? '50%' : '0',
          }}
        />
      ))}
    </div>
  )
}
